package com.example.journey;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);


        Button addNew = findViewById(R.id.addNew);
        Button photoButton = findViewById(R.id.Photo);
        Button videoButton = findViewById(R.id.Video);
        Button privacyButton = findViewById(R.id.Privacy);
        Button lifeEventsButton = findViewById(R.id.lifeEvents);
        Button notesButton = findViewById(R.id.Notes);

        TextView photoCount = findViewById(R.id.photo_count);
        TextView videoCount = findViewById(R.id.photo_count2);
        TextView privacyStatus = findViewById(R.id.photo_count3);
        TextView lifeEventsCount = findViewById(R.id.photo_count4);
        TextView notesCount = findViewById(R.id.photo_count5);

        addNew.setOnClickListener(view -> {
            Intent intent = new Intent(Profile.this, Thoughts.class);
            startActivity(intent);
        });

        // Show the counts when buttons are clicked
        photoButton.setOnClickListener(view ->
                Toast.makeText(Profile.this, "Photos: " + photoCount.getText().toString(), Toast.LENGTH_SHORT).show());

        videoButton.setOnClickListener(view ->
                Toast.makeText(Profile.this, "Videos: " + videoCount.getText().toString(), Toast.LENGTH_SHORT).show());

        privacyButton.setOnClickListener(view ->
                Toast.makeText(Profile.this, "Privacy: " + privacyStatus.getText().toString(), Toast.LENGTH_SHORT).show());

        lifeEventsButton.setOnClickListener(view ->
                Toast.makeText(Profile.this, "Life Events: " + lifeEventsCount.getText().toString(), Toast.LENGTH_SHORT).show());

        notesButton.setOnClickListener(view ->
                Toast.makeText(Profile.this, "Notes: " + notesCount.getText().toString(), Toast.LENGTH_SHORT).show());
    }
}
