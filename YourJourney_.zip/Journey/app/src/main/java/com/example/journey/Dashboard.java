package com.example.journey;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Dashboard extends AppCompatActivity {

    boolean isLiked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        ImageButton like = findViewById(R.id.likeIcon);
        ImageButton heart = findViewById(R.id.heartIcon);
        ImageButton menuIcon = findViewById(R.id.menuIcon);
        EditText searchField = findViewById(R.id.search);
        EditText commentField = findViewById(R.id.commentEditText);
        EditText comment = findViewById(R.id.etComment);


        searchField.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, Profile.class);
                startActivity(intent);

            }
        });

        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isLiked) {
                    like.setColorFilter(Color.RED); // Change to red
                    Toast.makeText(Dashboard.this, "You liked this post.", Toast.LENGTH_SHORT).show();
                    isLiked = true;
                } else {
                    like.setColorFilter(Color.parseColor("#6B5457"));
                    isLiked = false;
                }
            }
        });


        heart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isLiked) {
                    heart.setColorFilter(Color.RED); // Change to red
                    Toast.makeText(Dashboard.this, "You liked this post.", Toast.LENGTH_SHORT).show();
                    isLiked = true;
                } else {
                    heart.setColorFilter(Color.parseColor("#6B5457"));
                    isLiked = false;
                }
            }
        });

        commentField.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String commentText = commentField.getText().toString().trim();
                if (!commentText.isEmpty()) {
                    Toast.makeText(Dashboard.this, "Comment posted.", Toast.LENGTH_SHORT).show();
                    commentField.setText(""); // Clear the comment field
                }
            }
        });

        comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String commentText = comment.getText().toString().trim();
                if (!commentText.isEmpty()) {
                    Toast.makeText(Dashboard.this, "Comment posted.", Toast.LENGTH_SHORT).show();
                    comment.setText(""); // Clear the comment field
                }
            }
        });

        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, Menu.class);
                startActivity(intent);
            }
        });
    }
}
