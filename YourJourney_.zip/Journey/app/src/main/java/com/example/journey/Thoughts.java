package com.example.journey;

import static org.jetbrains.annotations.Nls.Capitalization.Title;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;


public class Thoughts extends AppCompatActivity {

    EditText tvTitle;
    Button btnAttachPhoto, btnAttachVideo, btnUpload;

    ImageButton btnBack;
    CheckBox checkboxPublic, checkboxPrivate;

    Uri selectedMediaUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_thoughts);

        tvTitle = findViewById(R.id.tvTitle);
        btnAttachPhoto = findViewById(R.id.btnAttachPhoto);
        btnAttachVideo = findViewById(R.id.btnAttachVideo);
        btnUpload = findViewById(R.id.btnUpload);
        checkboxPublic = findViewById(R.id.checkboxPublic);
        checkboxPrivate = findViewById(R.id.checkboxPrivate);
        btnBack = findViewById(R.id.btnBack);

        ActivityResultLauncher<Intent> pickPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        selectedMediaUri = result.getData().getData();
                        Toast.makeText(this, "Photo selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        btnAttachPhoto.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            pickPhotoLauncher.launch(intent);
        });

        ActivityResultLauncher<Intent> pickVideoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        selectedMediaUri = result.getData().getData();
                        Toast.makeText(this, "Video selected", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        btnAttachVideo.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("video/*");
            pickVideoLauncher.launch(intent);
        });


        btnUpload.setOnClickListener(v -> {
            String title = tvTitle.getText().toString().trim();
            if (title.isEmpty() || selectedMediaUri == null || (!checkboxPublic.isChecked() && !checkboxPrivate.isChecked())) {
                Toast.makeText(this, "Please complete all fields before uploading", Toast.LENGTH_SHORT).show();
            } else {
                // I-clear ang input fields
                tvTitle.setText("");
                selectedMediaUri = null;
                checkboxPublic.setChecked(false);
                checkboxPrivate.setChecked(false);

                Toast.makeText(this, "Already posted", Toast.LENGTH_SHORT).show();
            }
        });

        btnBack.setOnClickListener(v -> {
            finish();
        });
    }
    }
