package com.example.journey;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Toast.makeText(MainActivity.this, "Embark on your journey! Login to begin.", Toast.LENGTH_SHORT).show();

        EditText Email = findViewById(R.id.email);
        EditText Password = findViewById(R.id.pass);
        Button btnLogin = findViewById(R.id.btnLogIn);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateLogin();
            }

            private void validateLogin() {

                String email = Email.getText().toString().trim();
                String password = Password.getText().toString().trim();


                if (email.isEmpty()) {
                    Email.setError("Please enter your email!");
                    Email.requestFocus();
                    return;
                }


                if (password.isEmpty()) {
                    Password.setError("Please enter your password!");
                    Password.requestFocus();
                    return;
                }

                Toast.makeText(MainActivity.this, "You Login Successfully!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, Dashboard.class);
                startActivity(intent);
            }

        });
    }
}
