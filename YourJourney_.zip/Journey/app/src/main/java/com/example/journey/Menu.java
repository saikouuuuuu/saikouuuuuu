package com.example.journey;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu);

        ImageButton btnBack = findViewById(R.id.btnBack);
        Button btnProf = findViewById(R.id.btnProf);
        Button btnLogOut = findViewById(R.id.btnLogOut);
        Button btnAddNew = findViewById(R.id.btnAddNew);
        Button btnSettings = findViewById(R.id.btnSettings);
        Button btnSwitchAccount = findViewById(R.id.btnSwitchAcc);

        btnBack.setOnClickListener(view -> {
            Intent intent = new Intent(Menu.this, Dashboard.class);
            startActivity(intent);
            finish();

        });

        btnProf.setOnClickListener(view -> {
            Intent intent = new Intent(Menu.this, Profile.class);
            startActivity(intent);
        });

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Menu.this, "Your account has been logged out.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Menu.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnAddNew.setOnClickListener(view -> {
            Intent intent = new Intent(Menu.this, Thoughts.class);
            startActivity(intent);
        });


        btnSettings.setOnClickListener(view -> {
            Intent intent = new Intent(Menu.this, Settings.class);
            startActivity(intent);
        });

        btnSwitchAccount.setOnClickListener(view -> {
            Intent intent = new Intent(Menu.this, MainActivity.class);
            startActivity(intent);
        });

    }
}

